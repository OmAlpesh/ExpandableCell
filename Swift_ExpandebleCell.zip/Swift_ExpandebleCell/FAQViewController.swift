//
//  FAQViewController.swift
//  NuevacareCaregiver
//
//  Created by alpesh patel on 12/26/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit


class FAQViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tblFAQ: UITableView!

    var arrayTabIsOpen = [Any]()
    
    var LblHeaderName: UILabel!
     var LblHeaderLine: UILabel!
    
    @IBOutlet weak var lblTitle: UILabel!
     var arrFAQQuestion = NSArray(array: ["AAA xxx xccxcxc fsfsfsfsffs f sfdsf sffsfsfs", "BBB", "CCCsdfdsfs  ffdsfs fsf sfsffsfdsf", "DDD sfsfsfsdfdsfs", "EEE  fdsf fs fsdfdsf", "FFF ffsfdsfdsfdsdfdfdsf vvvv vvvvv vvvv vvvvvv vvvvv vvvvvv  vvvvvvv vvvvvvvv vvvvvvvvv vvvvvvv vvvvvv"])
    var arrFAQAns = NSArray(array: ["AAA XXX fasddasdad dd dsf fdsfdsfdsf ffsfdsfdsf dsfdsfsdfdsf dsfdsfsdfdsfsdf s", "BBB XXX fsddsdadaasdtertegd et ertert tert eet tet ert t teterter gtertert eterte", "CCC XXX  erterterter  retertret ert tterterterter tetert", "DDD XXX tterttertrerwerr tret  teter tert er t zzzzz zzzzzzz zzzzzzzzzzz zzzzzzz zzzzzzzzzzz zzzzzzzzzzzz zzzzzzzzzz zzzzzzzzzzz zzzzzzzzzz zzzzzz  zzz zzz zzzz", "EEE XXX ttertertertertertrtertertert erttetert ttreterr rwer r ewr ew rwrew rrewrxxxxx xxxx xxxx xxx xx ", "FFF XXX bb vbb bvbfbcvbvcbgg ffffdsfs gggdffg trt fgdfgdfg gdgdfgdfgd ggdfgd gf gdgdfgdfg dfg gdfgdfg d gdfgdfgdfg d gdfgdfgdfgdffgdgdfg dgdgdf gdgdfg dfgdfgdf gdfgdfgdgdfty rnhfghfhfg kkkjkjkkklkkkkkkkk mmmmmmmmmmmm"])

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        for i in 0..<arrFAQQuestion.count {
            
            arrayTabIsOpen.append(false)
        }

        print(arrayTabIsOpen)
        
          self.setUPTableView()
        
            
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:- SetUpFont
    
    func  setUPFont()
    {
        
        if(Constant.isiPhone_6_Plus)
        {
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 20.0)
           
        }
        if(Constant.isiPhone_6)
        {
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 18.0)
          
        }
        if(Constant.isiPhone_5)
        {
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 15.0)
        }
    }

    //MARK:- SetUpTableView
    func  setUPTableView(){
        
        tblFAQ.register(UINib(nibName: "FAQCell", bundle: nil), forCellReuseIdentifier: "FAQCell")
        
        tblFAQ.estimatedRowHeight = 115
        tblFAQ.rowHeight = UITableViewAutomaticDimension
        
         tblFAQ.estimatedSectionHeaderHeight = 50
         tblFAQ.sectionHeaderHeight = UITableViewAutomaticDimension
        
    
        self.tblFAQ.reloadData()
    }

    
    //MARK:- UITableViewDelegate & DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        if CBool(arrayTabIsOpen[section] as! Bool) {
            return 1
        }
        else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
         return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell  = tableView.dequeueReusableCell(withIdentifier: "FAQCell", for: indexPath as IndexPath) as! FAQCell
        
        cell.lblQuestion.text = (arrFAQAns [indexPath.section] as! String)
        
        DispatchQueue.main.async {
            
            if(Constant.isiPhone_6_Plus)
            {
                self.LblHeaderName.font =  UIFont(name: "Montserrat-Regular", size: 20.0)
            }
            if(Constant.isiPhone_6)
            {
                self.LblHeaderName.font =  UIFont(name: "Montserrat-Regular", size: 18)
            }
            if(Constant.isiPhone_5)
            {
                self.LblHeaderName.font =  UIFont(name: "Montserrat-Regular", size: 15)
            }
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
    }

    //MARK:- HeaderView Method

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView()
        headerView.backgroundColor = UIColor.white
        
        headerView.tag = section
        
        LblHeaderName = UILabel(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(headerView.bounds.width), height: CGFloat(headerView.bounds.height)))
        LblHeaderName.textAlignment = .left
        LblHeaderName.text = (arrFAQQuestion [section] as! String)
        
        if(Constant.isiPhone_6_Plus)
        {
            self.LblHeaderName.font =  UIFont(name: "Montserrat-Regular", size: 20.0)
        }
        if(Constant.isiPhone_6)
        {
            self.LblHeaderName.font =  UIFont(name: "Montserrat-Regular", size: 18)
        }
        if(Constant.isiPhone_5)
        {
            self.LblHeaderName.font =  UIFont(name: "Montserrat-Regular", size: 15)
        }
        
        LblHeaderName.backgroundColor = UIColor.white
        LblHeaderName.translatesAutoresizingMaskIntoConstraints = false
        
        LblHeaderName.numberOfLines = 0
        
        LblHeaderName.textColor = UIColor.init(red: 65.0/255.0, green: 89.0/255.0, blue: 104.0/255.0, alpha: 1.0)
        
        headerView.addSubview(LblHeaderName)
        
        
        LblHeaderLine = UILabel(frame: CGRect(x: CGFloat(0), y: CGFloat(50), width: CGFloat(headerView.bounds.width), height: CGFloat(5)))
        LblHeaderLine.backgroundColor = UIColor.init(red: 235.0/255.0, green: 235.0/255.0, blue: 235.0/255.0, alpha: 1.0)
    
        LblHeaderLine.translatesAutoresizingMaskIntoConstraints = false
        
        headerView.addSubview(LblHeaderLine)
        
        
        if #available(iOS 9.0, *) {
            
            let margins = headerView.layoutMarginsGuide
           
            LblHeaderName.leadingAnchor.constraint(equalTo: margins.leadingAnchor, constant: 0).isActive = true
            
            LblHeaderName.trailingAnchor.constraint(equalTo: margins.trailingAnchor, constant: 0).isActive = true
            
            LblHeaderName.topAnchor.constraint(equalTo: margins.topAnchor, constant: 0).isActive = true
            
            LblHeaderLine.heightAnchor.constraint(equalToConstant: 2.0).isActive = true
            
            LblHeaderLine.leadingAnchor.constraint(equalTo: margins.leadingAnchor, constant: 0).isActive = true
            
            LblHeaderLine.trailingAnchor.constraint(equalTo: margins.trailingAnchor, constant: 0).isActive = true
            
            LblHeaderLine.topAnchor.constraint(equalTo: LblHeaderName.bottomAnchor, constant: 10).isActive=true
            
            LblHeaderLine.bottomAnchor.constraint(equalTo: margins.bottomAnchor, constant: 0).isActive = true
            
        } else {
            // Fallback on earlier versions
        }
     
        
        if CBool(arrayTabIsOpen[section] as! Bool) {
            
            if #available(iOS 9.0, *) {
                LblHeaderLine.heightAnchor.constraint(equalToConstant: 0.0).isActive = true
            } else {
                // Fallback on earlier versions
            }
        }
        else {
            
            if #available(iOS 9.0, *) {
                LblHeaderLine.heightAnchor.constraint(equalToConstant: 2.0).isActive = true
            } else {
                // Fallback on earlier versions
            }
        }
        

        let headerTapped = UITapGestureRecognizer(target: self, action: #selector(self.sectionHeaderTapped))
        headerView.addGestureRecognizer(headerTapped)
        
        return headerView
    }
   
     func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
//        if section == 0 {
//            return CGFloat.leastNormalMagnitude
//        }
//        return tableView.sectionHeaderHeight
        
         return UITableViewAutomaticDimension
        
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
    
       return arrFAQQuestion.count
    }
    
    //MARK:- Tap Gesture Method in Header
    
    func sectionHeaderTapped(_ gestureRecognizer: UITapGestureRecognizer) {
        
     
        print(gestureRecognizer.view?.tag as Any)
        
        
        var indexPath = IndexPath(row: 0, section: (gestureRecognizer.view?.tag)!)
        
         print(indexPath)
        
        var collapsed = CBool(arrayTabIsOpen[indexPath.section] as! Bool)
        
        print(collapsed)
        
        collapsed = !collapsed
        
        arrayTabIsOpen[indexPath.section] = Bool(collapsed)
        
    
        for i in 0..<arrayTabIsOpen.count {
            
            if indexPath.section != i {
                
                if CBool(arrayTabIsOpen[i] as! Bool) == true {
                    
                    arrayTabIsOpen[i] = false
                    
                }
            }
        }
        
          print(arrayTabIsOpen)
        
        tblFAQ.reloadData()
    }
    
    @IBAction func btnBack(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
}



