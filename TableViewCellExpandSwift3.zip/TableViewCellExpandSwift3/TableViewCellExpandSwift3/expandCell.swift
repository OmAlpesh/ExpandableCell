//
//  expandCell.swift
//  TableViewCellExpandSwift3
//
//  Created by piyush sinroja on 06/01/17.
//
//

import UIKit

class expandCell: UITableViewCell {

    @IBOutlet weak var lblDesc: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
