//
//  NotificationCell.swift
//  NuevacareClient
//
//  Created by Bhavik  on 14/10/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit

class FAQCell: UITableViewCell {

    @IBOutlet weak var lblQuestion : UILabel!
  
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
       
        
        if(Constant.isiPhone_6)
        {
            lblQuestion.font = UIFont(name: (lblQuestion.font?.fontName)!, size: 16)
            
        }
        if(Constant.isiPhone_6_Plus)
        {
            lblQuestion.font = UIFont(name: (lblQuestion.font?.fontName)!, size: 18)
         
        }
        if(Constant.isiPhone_5)
        {
            lblQuestion.font = UIFont(name: (lblQuestion.font?.fontName)!, size: 14)
        
        }

    }

}
